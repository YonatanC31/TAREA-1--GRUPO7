﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ejercicio1.Ejercicio1Calculadora
{
    public partial class CalculatorForm : Form
    {
        public CalculatorForm()
        {
            InitializeComponent();
        }

        private void SumaButton_Click(object sender, EventArgs e)
        {
            int firstNumber = Convert.ToInt32(FirstNumberTexbox.Text);
            int secondNumber = Convert.ToInt32(SecondNumberTexbox.Text);

            int result = firstNumber + secondNumber;

            ResultLabel.Text = $"La sumatoria de {firstNumber} + {secondNumber} = {result}";
        }

        private void RestButton_Click(object sender, EventArgs e)
        {
            int firstNumber = Convert.ToInt32(FirstNumberTexbox.Text);
            int secondNumber = Convert.ToInt32(SecondNumberTexbox.Text);

            int result = firstNumber - secondNumber;

            ResultLabel.Text = $"La resta de {firstNumber} - {secondNumber} = {result}";
        }

        private void MultiplierButton_Click(object sender, EventArgs e)
        {
            int firstNumber = Convert.ToInt32(FirstNumberTexbox.Text);
            int secondNumber = Convert.ToInt32(SecondNumberTexbox.Text);

            int result = firstNumber * secondNumber;

            ResultLabel.Text = $"La multiplicación de {firstNumber} * {secondNumber} = {result}";
        }


        private void MultiplierButton_MouseUp(object sender, MouseEventArgs e)
        {
            MultiplierButton.BackColor = Color.Yellow;
        }

        private void SumaButton_MouseEnter_1(object sender, EventArgs e)
        {
            SumaButton.BackColor = Color.LightGreen;

        }

        private void RestButton_MouseLeave_1(object sender, EventArgs e)
        {
            RestButton.BackColor = Color.LightBlue;
        }

        private void MultiplierButton_MouseDown_1(object sender, MouseEventArgs e)
        {
            MultiplierButton.BackColor = Color.Yellow;
        }
    }
}
