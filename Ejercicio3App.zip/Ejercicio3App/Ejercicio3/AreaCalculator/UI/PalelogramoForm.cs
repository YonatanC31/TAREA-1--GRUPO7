﻿using Ejercicio3.AreaCalculator.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ejercicio3.AreaCalculator.Views
{
    public partial class PalelogramoForm : Form
    {
        public PalelogramoForm()
        {
            InitializeComponent();
        }

        private void CalcularPalelogramaButton_Click(object sender, EventArgs e)
        {
            double basePalelogramo = double.Parse(BaseTexbox.Text);
            double alturaPalelogramo = double.Parse(AlturaTexbox.Text);

            Palelogramo palelogramo = new Palelogramo(basePalelogramo, alturaPalelogramo);

            double resultado = 0;

            if (OpcionesComboBox.SelectedItem.ToString() == "Area")
            {
                resultado = palelogramo.CalcularArea();
            }
            else if (OpcionesComboBox.SelectedItem.ToString() == "Perimetro")
            {
                resultado = palelogramo.CalcularPerimetro();
            }

            MessageBox.Show("El resultado es: " + resultado);
        }

        private void CalcularPalelogramaButton_MouseClick(object sender, MouseEventArgs e)
        {
           CalcularPalelogramaButton.BackColor = Color.Gold;
        }
    }
}
