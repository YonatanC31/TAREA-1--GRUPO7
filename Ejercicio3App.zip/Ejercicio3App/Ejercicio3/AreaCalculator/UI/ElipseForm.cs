﻿using Ejercicio3.AreaCalculator.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ejercicio3.AreaCalculator.Views
{
    public partial class ElipseForm : Form
    {
        public ElipseForm()
        {
            InitializeComponent();
        }

        private void ElipseButton_Click(object sender, EventArgs e)
        {

            double ejeMayor = double.Parse(EjeMayorTexbox.Text);
            double ejeMenor = double.Parse(EjeMenorTexbox.Text);

            Elipse elipse = new Elipse(ejeMayor, ejeMenor);

            double resultado = 0;


            if (OpcionesElipseTexbox.SelectedItem.ToString() == "Area")
            {
                resultado = elipse.CalcularArea();
            }
            else if (OpcionesElipseTexbox.SelectedItem.ToString() == "Perimetro")
            {
                resultado = elipse.CalcularPerimetro();
            }


            MessageBox.Show("El resultado es: " + resultado);
        }

        private void ElipseButton_MouseClick(object sender, MouseEventArgs e)
        {
            ElipseButton.BackColor = Color.Gold;
        }
    }
}
